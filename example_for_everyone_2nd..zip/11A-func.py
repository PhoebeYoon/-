# 함수를 정의하고 호출하느 프로그램
def hello():  # hello 함수를 정의합니다.
    print("Hello Python!")

hello()      # hello 함수를 호출합니다.
hello()
hello()
